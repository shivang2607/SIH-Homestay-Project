import React from 'react'

const HomeOwner = () => {
  return (
    <div>HomeOwner</div>
  )
}

export default HomeOwner